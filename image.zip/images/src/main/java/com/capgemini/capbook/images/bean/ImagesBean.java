package com.capgemini.capbook.images.bean;

import java.io.File;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="Images")
public class ImagesBean {
	@Id
	@Column(name="imageId")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer imageId;                                                                                        
	private String postDisc;                                                                                        
	private String imageUrl; 
	//private String albumId;
	@Transient
	private File file;

	public ImagesBean() {
		
	}

	public ImagesBean(Integer imageId, String postDisc, String imageUrl) {
		super();
		this.imageId = imageId;
		this.postDisc = postDisc;
		this.imageUrl = imageUrl;
	}

	public ImagesBean(Integer imageId, String postDisc, String imageUrl, File file) {
		super();
		this.imageId = imageId;
		this.postDisc = postDisc;
		this.imageUrl = imageUrl;
		this.file = file;
	}

	public Integer getImageId() {
		return imageId;
	}

	public void setImageId(Integer imageId) {
		this.imageId = imageId;
	}

	public String getPostDisc() {
		return postDisc;
	}

	public void setPostDisc(String postDisc) {
		this.postDisc = postDisc;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	
	public File getFile() {
		return file;
	}

	public void setFile(File file) {
		this.file = file;
	}

	@Override
	public String toString() {
		return "ImagesBean [imageId=" + imageId + ", postDisc=" + postDisc + ", imageUrl=" + imageUrl + ", file=" + file
				+ "]";
	}

	


}
