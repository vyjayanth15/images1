package com.capgemini.capbook.images.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.capbook.images.bean.ImagesBean;

@Repository("profiledao")
@Transactional
public interface IProfileDao extends JpaRepository<ImagesBean, Integer> {


}
